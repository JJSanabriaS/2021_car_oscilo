//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SniffUSB.rc
//
#define IDC_DELETE                      3
#define IDC_VIEW                        4
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SNIFFUSB_DIALOG             102
#define IDS_FILTERNAME                  102
#define IDS_FILTERNAME_98               102
#define IDS_LOWERFILTERS                103
#define IDS_COL_VIDPID                  104
#define IDS_COL_FILTERINSTALLED         105
#define IDS_COL_DESCRIPTION             106
#define IDS_INSTALLED                   107
#define IDS_NOTINSTALLED                108
#define IDS_SELECT_ITEM_FIRST           109
#define IDS_FILTERNAME_NT               110
#define IDR_MAINFRAME                   128
#define IDR_SNOOPUSB                    130
#define SYS_SNOOPY_98                   500
#define SYS_SNOOPY_NT                   501
#define IDC_REFRESH                     1003
#define IDC_INSTALL                     1004
#define IDC_UNINSTALL                   1005
#define IDC_USBDEVS                     1006
#define IDC_REPLUG                      1007
#define IDC_FILTERINSTALL               1008
#define IDC_TEST                        1009
#define IDC_LOG_SIZE                    1010
#define IDC_LOG_FILENAME                1011
#define IDC_STATIC2                     1012
#define IDC_CHECK_AUTO_REFRESH          1013
#define IDC_COMBO_REFRESH_INTERVAL      1014
#define IDC_STATIC_LOG_FILE_BOX         1015
#define IDC_STATIC_FILTER_CONTROL_BOX   1016
#define IDC_STATIC_DISPLAY_CONTROL_BOX  1017
#define IDC_STATIC_AUTO_REFRESH_BOX     1018
#define IDC_STATIC_REFRESH_INTERVAL     1019
#define IDC_STATIC_DEVICE_LIST_BOX      1021
#define IDC_CHECK1                      1022
#define IDC_CHECK_LIST_NOT_PRESENT      1022
#define IDC_BUTTON1                     1023
#define IDC_BUTTON_UNINSTALL_ALL        1023
#define IDC_BUTTON_START                1024
#define IDC_BUTTON_RESUME               1025
#define IDC_BUTTON_STOP                 1025
#define IDC_BUTTON_CLOSE_FILE           1026
#define ID_SNOOPUSB_INSTALL             32780
#define ID_SNOOPUSB_UNINSTALL           32781
#define ID_SNOOPUSB_REPLUG              32782
#define ID_SNOOPUSB_CREATESERVICE       32783
#define ID_SNOOPUSB_DELETESERVICE       32784
#define ID_SNOOPUSB_STARTSERVICE        32785
#define ID_SNOOPUSB_STOPSERVICE         32786
#define IDS_COL_PRESENT                 57345
#define IDS_COL_DRIVER                  57346

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
